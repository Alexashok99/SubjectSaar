# यह DYNAMIC URLs के लिए बहुत महत्वपूर्ण है
# यह 'math_vvi' जैसे छोटे नाम को असली JSON फाइल पाथ से जोड़ता है
TEST_JSON_MAP = {
    "math_vvi": "data/most_save.json", # (यह फाइल static/data/ में होनी चाहिए)
    "top_20": "data/top_20.json",
    "algebra": "data/coordinate_all.json",
    "coordinate": "data/coordinate.json"
}